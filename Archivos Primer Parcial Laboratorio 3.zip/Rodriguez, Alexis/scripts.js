function ajax(url,method,async){
    
    var email = getElement("email").value;
    var pass = getElement("pass").value;
    var urlIndex = "./index.html";
        var xmlHttp = new XMLHttpRequest();
        var callBack = function(){
            if (xmlHttp.readyState === 4)
            {
                if (xmlHttp.status === 200)
                {
                    console.log(xmlHttp.response);
    
                    var response = JSON.parse(xmlHttp.response);

                    console.log(response);
                    
                    if (response.type == "error")
                    { 
                        getElement("errorText").style.visibility = "visible";
                        getElement("email").style.borderColor = "red";
                        getElement("pass").style.borderColor = "red";                        
                    }
                    else{
                        localStorage.setItem("type",response.type);
                        localStorage.setItem("email",email);
                        window.location.replace(urlIndex);
                    }
                }
            }
        }
    
        xmlHttp.onreadystatechange = callBack;
        
        
        var datosLogin = '{"email":"'+email+'","password":"'+pass+'"}';
        console.log("---------------");
    
        xmlHttp.open(method, url, async);
        xmlHttp.setRequestHeader("Content-type","application/json");
        if(email != "" && pass!= "")
        {
            xmlHttp.send(datosLogin);
        }
        else{
            xmlHttp.send();
        }
        
    
    }

    function cargaNoticias(){
        var auxBody = getElement("idBody");
        var auxNav = getElement("idNav");
        var url = "http://localhost:3000/noticias"; 
        var xmlHttp = new XMLHttpRequest();
        var callBack = function(){
            if (xmlHttp.readyState === 4)
            {
                if (xmlHttp.status === 200)
                {
                    var response = JSON.parse(xmlHttp.response);
                    for (i = 0; i < response.length; i++)
                    {
                        console.log(response);
                        auxBody.innerHTML = auxBody.innerHTML + 
                        "<section id="+response[i].tema +"><h1>" + response[i].titulo + " Fecha "+ response[i].fecha +"</h1>" 
                        + "<p>"+ response[i].noticia+ "</p>"+ "</section>";
                    }

                    for (i = 0; i < response.length; i++)
                    {
                        auxNav.innerHTML = auxNav.innerHTML +
                        "<a href="+response[i].tema + ">"+ response[i].tema + "</a>";
                    }

                
    
                    
                }
            }
        }

        xmlHttp.onreadystatechange = callBack;
    
        xmlHttp.open("GET", url, true);
            xmlHttp.send();
    }
    
    
    function LimpiarCampos()
    {
        var username = getElement("email");
        var pass = getElement("pass");
        //var xxxxx = getElement("xxxxxx");
        //var xxxxx = getElement("xxxxxx");
        //var xxxxx = getElement("xxxxxx");
        //var xxxxx = getElement("xxxxxx");
        //var xxxxx = getElement("xxxxxx");
    
        username.value = "";
        pass.value = "";
    }
    
    function getElement(id)
    {
        return document.getElementById(id);
    }
        