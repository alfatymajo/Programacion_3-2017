<?php
include_once "./helado.php";

$sabor = $_POST['sabor'];
$tipo = $_POST['tipo'];

$resultado = Helado::traerHelado($sabor,$tipo);
if ($resultado == "-1")
{
    echo "Sabor no encontrado";
}

if ($resultado == "-2")
{
    echo "Tipo no encontrado";
}

if ($resultado != "-1" && $resultado != "-2")
{
    echo $resultado;
}

?>