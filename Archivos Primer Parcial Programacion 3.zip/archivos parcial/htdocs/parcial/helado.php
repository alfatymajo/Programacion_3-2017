<?php
class Helado
{
    public $sabor;
    public $precio;
    public $tipo;
    public $cantidad;

    function __Construct($sabor, $precio, $tipo, $cantidad)
    {
        $this->sabor = $sabor;
        $this->precio = $precio;
        $this->tipo = $tipo;
        $this->cantidad = $cantidad;
    }

    public function guardar()
    {
        $archivo = fopen("./helados.txt","a");
        $renglon = $this->sabor.",".$this->precio.",".$this->tipo.",".$this->cantidad."\r\n";
        fwrite($archivo,$renglon);
        fclose($archivo);
    
    }

    public static function traerHelado($filtroSabor, $filtroTipo)
    {
        $archivo = fopen("./helados.txt","r");
        $result = "-1";
        while (feof($archivo) == false)
        {
        
            $line = fgets($archivo);

            $auxHelado = explode(",", $line);
            var_dump($auxHelado);
            if (count($auxHelado) == 4)
            {
                $auxSabor = $auxHelado[0];
                $auxTipo = $auxHelado[2];
            
                
                if($auxSabor == $filtroSabor )
                {
                    $result = "-2";
                }

                if ($auxSabor == $filtroSabor && $auxTipo == $filtroTipo)
                {
                   $result = "Si Hay";
                   break;
                }
            }
        }
        fclose($archivo);
        
        return $result;
    }

    public static function traerStock($filtroSabor, $filtroTipo)
    {
        $helado = Helado::traerHelado($filtroSabor, $filtroTipo);
        //var_dump($helado);
        if ($helado == "Si Hay")
        {
            $archivo = fopen("./helados.txt","r");
            $auxCantidad;
            while (feof($archivo) == false)
            {
                $line = fgets($archivo);

                $auxHelado = explode(",", $line);
                if(count($auxHelado) == 4)
                {
                    if($auxHelado[0] == $filtroSabor && $auxHelado[2] == $filtroTipo)
                    {
                        $auxCantidad = $auxHelado[3];
                    }
                }     
            }

            fclose($archivo);
            //var_dump($auxCantidad);

            return $auxCantidad;
        }

        return "-1";
    }

    public static function modificarStock($sabor, $tipo, $cantidad)
    {
        $archivo = fopen("./helados.txt","a");

        $listaHelados;
        while (feof($archivo) == false)
        {
            $line = fgets($archivo);
            $auxHelado = explode(",", $line);
            array_push($auxHelado);    
        }
        for ($i = 0; $i < count($listaHelados); $i++)
        {
            if ($listaHelados[i][0] == $sabor && $listaHelados[i][2] == $tipo)
            {
                $listaHelados[i][3] = $listaHelados[i][3] - $cantidad;
            }
        }
        
        fwrite($archivo,$listaHelados.tostring());
        fclose($archivo);
    
    }

    public static function guardarVenta($email, $sabor, $tipo, $cantidad)
    {
        $archivo = fopen("./venta.txt","a");
        $renglon = $email.",".$sabor.",".$tipo.",".$cantidad."\r\n";
        fwrite($archivo,$renglon);
        fclose($archivo);
    }

    public static function registrarVenta($email, $filtroSabor, $filtroTipo, $filtroCantidad)
    {
        $helado = Helado::traerHelado($filtroSabor,$filtroTipo);
        $resultado = "-1"; //No existe el helado

        if ($helado == "Si Hay")
        {
            $stock = Helado::traerStock($filtroSabor, $filtroTipo);

            //var_dump($stock);
            if ($stock == "-1")
            {
                $resultado = "-2"; //Existe pero no hay stock para realizar la venta
            }

            if ($stock > $filtroCantidad)
            {
                Helado::modificarStock($filtroSabor, $filtroTipo, $filtroCantidad);
                Helado::guardarVenta($email, $filtroSabor, $filtroTipo, $filtroCantidad);
                $resultado = "1"; //Venta Realizada correctamente
            }
        }

        return $resultado;
    }
    
}
?>