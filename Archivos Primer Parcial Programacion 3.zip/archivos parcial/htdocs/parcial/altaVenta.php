<?php
include_once "./helado.php";

$email = $_POST['email'];
$sabor = $_POST['sabor'];
$tipo = $_POST['tipo'];
$cantidad = $_POST['cantidad'];

$resultado = Helado::registrarVenta($email,$sabor, $tipo, $cantidad);

if ($resultado == "-1")
{
    echo "El Helado no existe";
}

if ($resultado == "-2")
{
    echo "No hay stock para realizar la venta";
}

if ($resultado == "1")
{
    echo "Venta realizada correctamente";
}

?>