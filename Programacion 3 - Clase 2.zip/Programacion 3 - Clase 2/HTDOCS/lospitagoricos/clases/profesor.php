<?php
include_once "./clases/persona.php";

class Profesor extends Persona
{
    private $idLegajo;

    public function __Construct($nombre,$apellido,$sexo,$idLegajo)
    {
        parent::__Construct($nombre,$apellido,$sexo);
        $this->idLegajo = $idLegajo;
    }

    public function mostrarDatos()
    {
        $datos = "Cargo: Profesor. "."Nombre: ".$this->nombre.". "."Apellido: ".$this->apellido.". "
                ."Sexo: ".$this->sexo.". "."Legajo Nro: ".$this->idLegajo.".";
        
        return $datos;
    }

    public function getIdLegajo()
    {
        return $this->idLegajo;
    }

    public function setIdLegajo($idLegajo)
    {
        $this->idLegajo = $idLegajo;
    }  
}


?>