<?php
abstract class Persona
{
    protected $nombre;
    protected $apellido;
    protected $sexo;
    public abstract function mostrarDatos();

    public function __Construct($nombre,$apellido,$sexo)
    {
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->sexo = $sexo;
    }

    protected function getNombre()
    {
        return $this->nombre;
    }
    protected function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    protected function getApellido()
    {
        return $this->apellido;
    }
    protected function setApellido($apellido)
    {
        $this->apellido = $apellido;
    }

    protected function getSexo()
    {
        return $this->sexo;
    }
    protected function setSexo($sexo)
    {
        $this->sexo = $sexo;
    }
}


?>


