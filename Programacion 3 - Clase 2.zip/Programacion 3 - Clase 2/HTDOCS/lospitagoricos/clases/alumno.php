<?php
include_once "./clases/persona.php";

class Alumno extends Persona
{
    private $idLibreta;

    public function __Construct($nombre,$apellido,$sexo,$idLibreta)
    {
        parent::__Construct($nombre,$apellido,$sexo);
        $this->idLibreta = $idLibreta;
    }

    public function mostrarDatos()
    {
        $datos = "Cargo: Alumno. "."Nombre: ".$this->nombre.". "."Apellido: ".$this->apellido.". "
                ."Sexo: ".$this->sexo.". "."Nro Libreta: ".$this->idLibreta.".";
        
        return $datos;
    }

    public function getIdLibreta()
    {
        return $this->idlibreta;
    }
    public function setIdLibreta($idLibreta)
    {
        $this->idLibreta = $idLibreta;
    }

}


?>