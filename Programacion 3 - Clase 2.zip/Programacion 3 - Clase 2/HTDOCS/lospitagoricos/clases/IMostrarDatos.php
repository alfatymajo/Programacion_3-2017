<?php

interface IMostrarDatos
{

    public function mostrarPersonas();

} 


?>