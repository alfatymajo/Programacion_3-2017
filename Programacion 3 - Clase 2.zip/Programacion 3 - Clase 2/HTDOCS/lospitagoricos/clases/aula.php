<?php
include_once "./clases/persona.php";
include_once "./clases/alumno.php";
include_once "./clases/profesor.php";
include_once "./clases/IMostrarDatos.php";

class Aula implements IMostrarDatos
{
    private $listaPersonas = array();

    public function mostrarPersonas()
    {
        foreach ($listaPersonas as $valor)
        {
            echo $valor->mostrarDatos()."<br>";
        }
    }
    public function getListaAlumnos()
    {
        return $this->listaAlumnos;
    }

    public function agregarPersona($persona)
    {
        array_push($this->listaPersonas,$persona);

    }


}


?>