<?php
include_once "./clases/persona.php";
include_once "./clases/aula.php";
include_once "./clases/profesor.php";
include_once "./clases/alumno.php";

$alumnoUno = new Alumno("Benny", "Rodriguez", "Masculino", 4569741);
$profesorUno = new Profesor("Benny", "Rodriguez", "Masculino", 4569741);

echo $alumnoUno->mostrarDatos();
echo "<br>";
echo $profesorUno->mostrarDatos();

?>