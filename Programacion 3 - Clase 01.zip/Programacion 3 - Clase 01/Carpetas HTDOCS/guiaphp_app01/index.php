<?php

$acum = 0;
$sum = 0;
$flag = true;

while ($sum <= 1000)
{
    // if ($flag)
    // {
    //     $sum = 0;
    //     $flag = false;
    // }

    for ($i = 1; $i < 1001; $i++ )
    {
        $sum = $sum + $i;
        $acum = $acum + 1;
        

        if ($sum > 1000)
        {
            break;
        }
        //else
        //{
        //    echo $sum ."<br>";
        //    continue;
        // }
            echo $sum ."<br>";
        
    }
}

echo "Numeros Sumados: ". $acum;


?>