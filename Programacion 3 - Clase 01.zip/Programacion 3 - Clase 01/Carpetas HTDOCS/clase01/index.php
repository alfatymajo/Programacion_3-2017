<?php

include_once "./clases/persona.php";
include_once "./clases/policia.php";
//Con require te aseguras que si no consigue encontrar el archivo el programa no sigue su curso. Con include Solamente lanza Warning y el codigo sigue.
//require "persona1.php";

$vec = array(1,2,3,5);

//Muestra Salidas de consola (tipo printf)
//echo $vec;

//Muestra ademas del contenido del array, tipos de datos contenidos, cantidad de indices, etc
//var_dump($vec);

//Para llamar metodos estaticos es Clase + :: + el metodo
Persona::saludarDos();

$persona = new Persona();

$persona->saludar();