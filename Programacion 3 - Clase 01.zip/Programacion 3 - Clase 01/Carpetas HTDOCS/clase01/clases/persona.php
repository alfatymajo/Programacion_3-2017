<?php
class Persona
{
    function saludar()
    {
        echo "Hola Mundo!!"."<br>";
    }

    static function saludarDos()
    {
        echo "Hola Mundo Estatico!!"."<br>";
    }
}

?>