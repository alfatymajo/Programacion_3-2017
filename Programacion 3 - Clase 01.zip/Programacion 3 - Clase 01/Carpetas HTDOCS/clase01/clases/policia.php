<?php

include_once "./clases/persona.php";
class Policia
{
    public $nombre;
    public $apellido;
    public $dni;

    //Para crear constructores es con dos guiones bajo y la palabra clave Construct
    //Poniendo varios variables logramos "Simular" La sobrecarga de metodo, la cual no es posible en php.
    public function __Construct($nombre, $apellido="",$dni="")
    {
        //Para ahcer referencia a las variables de la clase $this -> y el nombre de la variable sin el simbolo $
        $this->nombre = $nombre;
    }
}

?>