<?php

INSERT INTO `datos`(`NOMBRE`, `APELLIDO`, `FECHANAC`, `NACIONALIDAD`) VALUES ('Natalia','Natalia','20170919','Argentina')
//Reglas basicas del insert

//Los auto incrementales no se insertan . La misma cantidad de parametros de la isqueirda tiene que ser la misma
//de la derecha

//Para agregar varios registros en un solo insert

INSERT INTO `datos`(`NOMBRE`, `APELLIDO`, `FECHANAC`, `NACIONALIDAD`) VALUES ('Galileo','Galilei','20170919','Argentina'),
('Edgar','Poe','20170919','Argentina'),
('Conan','Doyle','20170919','Argentina')

//Update sin where actualiza todas las tablas

UPDATE `datos` SET `NOMBRE`= 'Juan'

//Para usar mas parametros

UPDATE `datos` SET `NOMBRE`= 'Juan', 'APELLIDO' = "Perez"

//Select de 2 tablas con alias

SELECT d.NOMBRE, l.DESCRIPCION FROM datos as d, localidad as l
WHERE d.LOCALIDAD = l.ID
?>