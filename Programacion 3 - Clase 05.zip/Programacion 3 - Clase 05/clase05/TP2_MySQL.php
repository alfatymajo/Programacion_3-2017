<?php
1- Tablas creadas por la interfaz

2- Insertar los datos a las tablas

//Inserto primero un id para que los demas sean autoincremental
INSERT INTO `proveedores`(`NUMERO`, `NOMBRE`, `DOMICILIO`, `LOCALIDAD`) VALUES (100,'Perez','Peron 876','Quilmes')
INSERT INTO `proveedores`(`NOMBRE`, `DOMICILIO`, `LOCALIDAD`) 
VALUES 
('Gimenez','Mitre 750','Avellaneda'),
('Aguirre','Boedo 634','Bernal')

INSERT INTO `productos`(`pNUMERO`, `pNOMBRE`, `PRECIO`, `TAMAÑO`) VALUES (1,'Caramelos',1.5,'Chico')
INSERT INTO `productos`(`pNOMBRE`, `PRECIO`, `TAMAÑO`) 
VALUES 
('Cigarrillos',45.89,'Mediano'), ('Gaseosa',15.80,'Grande')

INSERT INTO `envios`(`NUMERO`, `pNUMERO`, `CANTIDAD`) 
VALUES 
(100,1,500), 
(100,2,1500), 
(100,3,100), 
(101,2,55), 
(101,3,225), 
(102,1,600), 
(102,3,300)

3.1- Detalles de productos ordenados alfabeticamente

SELECT * FROM `productos` as p ORDER BY p.pNOMBRE asc

3.2 Detalles completos de todos los proveedores de Quilmes

SELECT * FROM `proveedores` as p WHERE p.LOCALIDAD = 'Quilmes'

3.3 Obtener todos los envios que la cantidad este entre 200 y 300 inclusive

SELECT * FROM `envios` as e WHERE e.CANTIDAD BETWEEN 200 AND 300

3.4 Cantidad total de todos los productos enviados

SELECT SUM(CANTIDAD) FROM `envios`

3.5 Mostrar los primeros 3 numeros de productos que se enviaron

SELECT e.pNUMERO FROM `envios` as e LIMIT 3

3.6 Mostrar los nombres de proveedores y los nombres de los productos enviados

SELECT p.NOMBRE as 'Nombre Proveedor', pr.pNOMBRE 
FROM `proveedores` as p, `productos` as pr
WHERE
?>