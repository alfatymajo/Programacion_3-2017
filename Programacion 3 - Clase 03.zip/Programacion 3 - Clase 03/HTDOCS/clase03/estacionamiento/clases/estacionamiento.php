<?php



class Estacionamiento{
/*
Toma el vehiculo y lo guarda en un archivo.

*/
public static function guardar($unAuto){

    $archivo = fopen("./archivos/estacionados.txt","a");
    $renglon = $unAuto->patente."**".$unAuto->fechaIngreso.".\n";
    fwrite($archivo,$renglon);
    fclose($archivo);
    //var_dump($unAuto);

    }

    /*
        1-lee (explode)
        2-Verifica (compara con la patente)
        3-Si lo encuentra calcula el costo.(strtotime )
        4-Sacar del array y volver a meter el array que quedo sin el vehiculo al archivo nuevamente (estacionados)
        5-Guardar facturados.txt (tiene que estar en la carpeta archivos).
        6- En el guardar tomar una foto que previamente se cargo en gestion.php que viene del postman y guardala
            en un subdirectorio y ponerle de nombre la patente + la fecha de ingreso (move_uploaded_file)
    */
    public static function sacar($unAuto){

    $archivo = fopen("./archivos/estacionados.txt","a");

    while (feof($archivo) == false)
    {
        
    }
    //var_dump($unAuto);

    }
}


?>