<?php

class Vehiculo{

public $patente;
public $fechaIngreso;
public $fechaEgreso;
public $importe;

function __Construct($patente){
    $this->patente = $patente;
}

}
?>