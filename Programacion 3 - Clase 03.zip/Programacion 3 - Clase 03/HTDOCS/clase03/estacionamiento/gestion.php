<?php
include_once "./clases/vehiculo.php";
include_once "./clases/estacionamiento.php";
$patente = $_POST['patente'];
$accion = $_POST['accion']; 

//var_dump($_GET);
//var_dump($_POST);
//var_dump($_FILES);

//var_dump($_POST);

$vehiculo = new Vehiculo("EEE888");
$vehiculo->fechaIngreso = date("Y-m-d H:i:s");
Estacionamiento::guardar($vehiculo);

//var_dump($vehiculo);

//var_dump($patente);
//var_dump($accion);

/*
Si la accion es guardar pasar el vehiculo al metodo guardar de estacionamiento. Si la accion es sacar
se llamara al metodo sacar de estacionamiento pasandole el vehiculo como parametro. 


*/

?>